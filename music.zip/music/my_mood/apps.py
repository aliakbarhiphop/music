from django.apps import AppConfig


class MyMoodConfig(AppConfig):
    name = 'my_mood'
