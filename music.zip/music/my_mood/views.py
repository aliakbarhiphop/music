from django.shortcuts import render
from django.core.files.storage import FileSystemStorage


def index(request):
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['music']
        # fs = FileSystemStorage(location='my_mood/musics')
        # fileName = fs.save(uploaded_file.name, uploaded_file)
        output = "Result From Model Put Here"
        context['output'] = output
        return render(request, 'result.html', context)
    return render(request, 'index.html', context)
